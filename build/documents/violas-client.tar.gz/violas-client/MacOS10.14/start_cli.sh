./violas-client -a ac.testnet.violas.io -p 40001 -s $(dirname "$PWD")/violas_consensus_peers.config.toml -m $(dirname "$PWD")/faucet_key_for_violas
